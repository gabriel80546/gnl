caminho=fWU3KdermTW3n9FRbtXwZ7AM
rm -rf -- $caminho/gnlcopia
cp -r -v -n $caminho/gnl $caminho/gnlcopia
